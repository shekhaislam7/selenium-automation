package com.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;

public class FacebookLoginAutomation {
    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\shaikh\\Downloads\\Compressed\\chromedriver.exe");

        // Initialize ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Open Facebook
        driver.get("https://www.facebook.com");

        // Enter username and password and click login
        driver.findElement(By.id("email")).sendKeys("03473535076");
        driver.findElement(By.id("pass")).sendKeys("Dell0312");
        driver.findElement(By.id("loginbutton")).click();

        // Close the browser
        driver.quit();
    }
}
